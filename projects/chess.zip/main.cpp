#include <iostream>
#include <SDL2/SDL.h>
#include "application.hpp"
#include "board.hpp"

using namespace std;

void drawBoard(SDL_Renderer &);

int main(int argc, char *argv[])
{
    Application app;
    int err = app.init();
    if (err > 0)
    {
        return 1;
    }

    SDL_Event event;
    bool quit = false;

    app.drawBoardPieces();
    app.updateRenderer();

    vector<vector<int>> moves;
    SDL_Point selectedPiece;
    while (!quit)
    {
        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_QUIT)
            {
                quit = true;
            }
            else if (event.type == SDL_MOUSEBUTTONDOWN)
            {
                // if click
                int mouseX = event.button.x;
                int mouseY = event.button.y;
                int clickedX = (mouseX - 320) / 75;
                int clickedY = (mouseY - 80) / 75;

                if (moves.empty())
                {
                    // No useful piece is selected (empty space, or not selected a square at all)
                    selectedPiece.x = clickedX;
                    selectedPiece.y = clickedY;
                    app.highlightSelected();
                    app.clearRenderer();
                    app.drawBoardPieces();
                    moves = app.highlightPossibleMovesFromPosition();
                    app.updateRenderer();
                }
                else
                {
                    // check if next selected is a valid move
                    bool validMove = false;
                    for (const auto &move : moves)
                    {
                        if (move[0] == clickedX && move[1] == clickedY)
                        {
                            validMove = true;
                            break;
                        }
                    }
                    if (validMove)
                    {
                        app.movePiece(selectedPiece.x, selectedPiece.y, clickedX, clickedY);
                        app.clearRenderer();
                        app.drawBoardPieces();
                        moves.clear();
                        app.updateRenderer();
                    }
                    else
                    {
                        moves.clear();
                    }
                }
            }
        }
        // app.draw();
    }

    IMG_Quit();
    SDL_Quit();

    return 0;
}
