#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <iostream>

#ifndef BOARDSQUARE_HPP
#define BOARDSQUARE_HPP

enum Pieces
{
    BlackBishop,
    BlackKing,
    BlackKnight,
    BlackPawn,
    BlackQueen,
    BlackRook,
    WhiteKing,
    WhiteKnight,
    WhitePawn,
    WhiteQueen,
    WhiteRook,
    WhiteBishop,
    Empty,
};

class BoardSquare
{
public:
    BoardSquare();
    BoardSquare(const BoardSquare &);

    SDL_Rect &returnTile();
    void setPosition(int, int);
    void setPiece(const Pieces &);
    void prepareTexture(std::string &, SDL_Renderer &);
    void selected(bool);
    bool getSelected() const;
    Pieces getPiece() const { return m_piece; };
    void changeColor(SDL_Renderer &);

    int m_x, m_y;
    Uint32 m_color[3];

private:
    bool m_hasMoved;
    SDL_Point position;
    int m_tile_len;
    SDL_Rect *m_tile;
    Pieces m_piece;
    bool m_selected;
};

#endif