#include "boardsquare.hpp"

BoardSquare::BoardSquare()
{
    m_tile = new SDL_Rect();
    m_piece = Pieces::Empty;
    m_selected = false;
    m_tile_len = 75;
    m_selected = false;
    m_hasMoved = false;
}

void BoardSquare::prepareTexture(std::string &fileref, SDL_Renderer &renderer)
{
    SDL_Surface *surface = IMG_Load(fileref.c_str());
    if (!surface)
    {
        std::cout << "IMG_Load error: " << IMG_GetError() << std::endl;
    }

    SDL_Texture *texture = SDL_CreateTextureFromSurface(&renderer, surface);
    SDL_FreeSurface(surface);

    SDL_Rect d;
    d.x = m_x;
    d.y = m_y;
    d.w = m_tile_len;
    d.h = m_tile_len;

    SDL_RenderCopy(&renderer, texture, NULL, &d);
}

void BoardSquare::selected(bool selected)
{
    m_selected = selected;
}

bool BoardSquare::getSelected() const
{
    return m_selected;
}

// Default size is 75x75
void BoardSquare::setPosition(int x, int y)
{
    m_tile->x = x;
    m_tile->y = y;
    m_tile->w = m_tile_len;
    m_tile->h = m_tile_len;
}

SDL_Rect &BoardSquare::returnTile()
{
    return *m_tile;
}

void BoardSquare::setPiece(const Pieces &piece)
{
    m_piece = piece;
}

void BoardSquare::changeColor(SDL_Renderer &renderer)
{
    SDL_SetRenderDrawColor(&renderer, 255, 0, 0, 255);
    SDL_RenderFillRect(&renderer, m_tile);
    SDL_RenderPresent(&renderer);
}

BoardSquare::BoardSquare(const BoardSquare &other)
{
    m_hasMoved = other.m_hasMoved;
    position = other.position;
    m_tile = new SDL_Rect(*other.m_tile);
    m_piece = other.m_piece;
    m_selected = other.m_selected;
}