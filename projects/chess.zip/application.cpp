
#include "application.hpp"
#include <iostream>
#include <stdlib.h>

Application::~Application() {}

void Application::draw()
{
    SDL_RenderClear(m_renderer);
    m_board->draw(*m_renderer);
    drawBoardPieces();
    SDL_RenderPresent(m_renderer);
}

int Application::init()
{
    if (SDL_Init(SDL_INIT_EVERYTHING) != 0)
    {
        std::cout << "SDL_Init Error: " << SDL_GetError() << std::endl;

        return 1;
    }

    int imgFlags = IMG_INIT_PNG;

    if (!(IMG_Init(imgFlags) & imgFlags))
    {
        std::cout << "SDL_image could not initialize! Error: " << IMG_GetError() << std::endl;
        return 1;
    }

    SDL_Window *window = SDL_CreateWindow("Chess", 100, 100, 1280, 960, SDL_WINDOW_SHOWN);
    if (window == nullptr)
    {
        std::cout << "SDL_CreateWindow Error: " << SDL_GetError() << std::endl;

        SDL_Quit();

        return 1;
    }

    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (renderer == nullptr)
    {
        std::cout << "SDL_CreateRenderer Error: " << SDL_GetError() << std::endl;

        SDL_DestroyWindow(window);
        SDL_Quit();

        return 1;
    }

    m_window = window;
    m_renderer = renderer;

    m_board = std::make_unique<Board>(*m_renderer);

    // create piece-to-fileref map
    m_board->m_piece_map = {
        {Pieces::BlackBishop, "pieces/black-bishop.png"},
        {Pieces::BlackKing, "pieces/black-king.png"},
        {Pieces::BlackKnight, "pieces/black-knight.png"},
        {Pieces::BlackPawn, "pieces/black-pawn.png"},
        {Pieces::BlackQueen, "pieces/black-queen.png"},
        {Pieces::BlackRook, "pieces/black-rook.png"},
        {Pieces::WhiteBishop, "pieces/white-bishop.png"},
        {Pieces::WhiteKing, "pieces/white-king.png"},
        {Pieces::WhiteKnight, "pieces/white-knight.png"},
        {Pieces::WhitePawn, "pieces/white-pawn.png"},
        {Pieces::WhiteQueen, "pieces/white-queen.png"},
        {Pieces::WhiteRook, "pieces/white-rook.png"},
    };

    return 0;
}

void Application::clearRenderer()
{
    // SDL_RenderClear(m_renderer);
}

void Application::updateRenderer()
{
    SDL_SetRenderDrawColor(m_renderer, 255, 255, 255, 255);
    // SDL_RenderClear(m_renderer);
    SDL_RenderPresent(m_renderer);
}

void Application::prepareTexture(std::string &fileRef, int x, int y)
{
    SDL_Surface *surface = IMG_Load(fileRef.c_str());
    if (!surface)
    {
        std::cout << "IMG_Load error: " << IMG_GetError() << std::endl;
        return;
    }
    SDL_Texture *texture = SDL_CreateTextureFromSurface(m_renderer, surface);
    SDL_FreeSurface(surface);

    SDL_Rect d = {x, y, 75, 75};

    SDL_RenderCopy(m_renderer, texture, NULL, &d);
}

// Draws pieces on board
// Shows Renderer
void Application::drawBoardPieces()

{
    std::string start = "rnbqkbnr/pppppppp/4N/8/8/8/PPPPPPPP/RNBQKBNR";

    m_board->drawBoardPieces(start, *m_renderer);
}

void Application::highlightSelected()
{

    SDL_Point mousePosition;

    SDL_GetMouseState(&mousePosition.x, &mousePosition.y);
    int boardX = (mousePosition.x - 320) / 75;
    int boardY = (mousePosition.y - 80) / 75;

    boardX = std::max(0, std::min(boardX, 7));
    boardY = std::max(0, std::min(boardY, 7));

    BoardSquare *square = m_board->returnSquare(boardX, boardY);
    if (square)
    {
        std::unique_ptr<BoardSquare> selected = std::make_unique<BoardSquare>(*square);

        m_board->setSelected(std::move(selected));
        m_board->updatePosition(*m_renderer);
        square->selected(true);
    }
}

vector<vector<int>> Application::highlightPossibleMovesFromPosition()
{
    SDL_Point mousePosition;
    SDL_GetMouseState(&mousePosition.x, &mousePosition.y);
    mousePosition.x = (mousePosition.x - 320) / 75;
    mousePosition.y = (mousePosition.y - 80) / 75;

    mousePosition.x = std::max(0, std::min(mousePosition.x, 7));
    mousePosition.y = std::max(0, std::min(mousePosition.y, 7));

    BoardSquare *selected = m_board->getSelected();
    vector<vector<int>> moves;

    switch (selected->getPiece())
    {
    case Pieces::WhitePawn:
    case Pieces::BlackPawn:
        moves = m_board->calculatePawn(*m_renderer, mousePosition.x, mousePosition.y);
        break;
    case Pieces::BlackKing:
    case Pieces::WhiteKing:
        moves = m_board->calculateKing(*m_renderer, mousePosition.x, mousePosition.y);
        break;
    case Pieces::BlackBishop:
    case Pieces::WhiteBishop:
        moves = m_board->calculateBishop(*m_renderer, mousePosition.x, mousePosition.y);
        break;
    case Pieces::WhiteRook:
    case Pieces::BlackRook:
        moves = m_board->calculateRook(*m_renderer, mousePosition.x, mousePosition.y);
        break;
    case Pieces::WhiteQueen:
    case Pieces::BlackQueen:
        moves = m_board->calculateQueen(*m_renderer, mousePosition.x, mousePosition.y);
        break;
    case Pieces::WhiteKnight:
    case Pieces::BlackKnight:
        moves = m_board->calculateKnight(*m_renderer, mousePosition.x, mousePosition.y);
        break;

    default:
        break;
    }

    // Set the draw blend mode to allow transparency
    SDL_SetRenderDrawBlendMode(m_renderer, SDL_BLENDMODE_BLEND);

    // Fill the squares with a translucent color
    SDL_SetRenderDrawColor(m_renderer, 0, 255, 0, 128); // Light green with transparency
    for (const auto &move : moves)
    {
        if (move[0] != -1)
        {
            SDL_Rect fillRect = {
                (move[0] * 75) + 320,
                (move[1] * 75) + 80,
                75,
                75};
            SDL_RenderFillRect(m_renderer, &fillRect);
        }
    }

    // Draw the outlines in a contrasting color
    SDL_SetRenderDrawColor(m_renderer, 255, 255, 0, 255); // Bright yellow for outline
    for (const auto &move : moves)
    {
        if (move[0] != -1)
        {
            SDL_Rect outlineRect = {
                (move[0] * 75) + 320,
                (move[1] * 75) + 80,
                75,
                75};
            SDL_RenderDrawRect(m_renderer, &outlineRect); // Draw the outline
        }
    }

    SDL_RenderPresent(m_renderer); // Update the screen

    return moves;
}

void Application::movePiece(int fromx, int fromy, int tox, int toy)
{
    m_board->movePiece(*m_renderer, fromx, fromy, tox, toy);
}