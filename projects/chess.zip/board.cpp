#include "board.hpp"

const int BOARD_OFFSET_X = 320;
const int BOARD_OFFSET_Y = 80;
const int BLOCK_SIZE = 75;

Board::~Board() {}

Board::Board(SDL_Renderer &renderer) : m_board(m_tile_x)
{
    int translate_y = 80;
    int translate_x = 320;
    for (int i = 0; i < m_tile_x; ++i)
    {
        m_board[i] = std::vector<std::unique_ptr<BoardSquare>>(m_tile_y);
        for (int j = 0; j < m_tile_y; ++j)
        {
            m_board[i][j] = std::make_unique<BoardSquare>();
            m_board[i][j]->setPosition((BLOCK_SIZE * i) + BOARD_OFFSET_X, (BLOCK_SIZE * j) + BOARD_OFFSET_Y);
            // m_board[i][j] = new BoardSquare();
            // m_board[i][j]->setPosition(((m_board_size / m_tile_x) * i) + translate_x, ((m_board_size / m_tile_x) * j) + translate_y);

            // ((i + j) % 2 == 0) ? SDL_SetRenderDrawColor(&renderer, 122, 122, 122, 255) : SDL_SetRenderDrawColor(&renderer, 235, 205, 35, 255);
            // SDL_RenderDrawRect(&renderer, &m_board[i][j]->returnTile());
            // SDL_RenderFillRect(&renderer, &m_board[i][j]->returnTile());
            renderTile(renderer, i, j);
        }
    }
}

void Board::updatePosition(SDL_Renderer &renderer)
{
    for (int i = 0; i < m_tile_x; ++i)
    {
        for (int j = 0; j < m_tile_y; ++j)
        {
            renderTile(renderer, i, j);
        }
    }
    if (m_currentSelected)
    {
        SDL_SetRenderDrawColor(&renderer, 255, 0, 0, 255);
        SDL_RenderFillRect(&renderer, &m_currentSelected->returnTile());
    }
    SDL_SetRenderDrawColor(&renderer, 255, 255, 255, 255);
}

BoardSquare *Board::getSelected()
{
    return m_currentSelected.get();
}

BoardSquare *Board::returnSquare(int posx, int posy) const
{
    return m_board[posx][posy].get();
}

void Board::setSelected(std::unique_ptr<BoardSquare> square)
{
    m_currentSelected = std::move(square);
}

void Board::resetColors()
{
    if (m_currentSelected)
    {
        m_currentSelected->selected(false);
        m_currentSelected = nullptr;
    }
}

void Board::setPiece(int i, int j, Pieces piece)
{
    m_board[i][j]->setPiece(piece);
}

void Board::prepareTexture(SDL_Renderer &renderer, const std::string &fileRef, int x, int y)
{
    SDL_Surface *surface = IMG_Load(fileRef.c_str());
    if (!surface)
    {
        std::cerr << "IMG_Load error: " << IMG_GetError() << std::endl;
        return;
    }
    SDL_Texture *texture = SDL_CreateTextureFromSurface(&renderer, surface);
    SDL_FreeSurface(surface);

    SDL_Rect d = {x, y, BLOCK_SIZE, BLOCK_SIZE};

    SDL_RenderCopy(&renderer, texture, NULL, &d);
}

void Board::drawBoardPieces(std::string &fen, SDL_Renderer &renderer)
{
    // std::string textureRef = "";
    int block_offset = 0;
    int y_offset = 0;
    for (int i = 0, col = 0; i < fen.length(); ++i, ++col)
    {
        Pieces currentPiece = Pieces::Empty;

        switch (fen[i])
        {
        case 'r':
            currentPiece = Pieces::BlackRook;
            break;

        case 'R':
            currentPiece = Pieces::WhiteRook;
            break;

        case 'n':
            currentPiece = Pieces::BlackKnight;
            break;

        case 'N':
            currentPiece = Pieces::WhiteKnight;
            break;

        case 'b':
            currentPiece = Pieces::BlackBishop;
            break;

        case 'B':
            currentPiece = Pieces::WhiteBishop;
            break;

        case 'q':
            currentPiece = Pieces::BlackQueen;
            break;

        case 'Q':
            currentPiece = Pieces::WhiteQueen;
            break;

        case 'k':
            currentPiece = Pieces::BlackKing;
            break;

        case 'K':
            currentPiece = Pieces::WhiteKing;
            break;

        case 'p':
            currentPiece = Pieces::BlackPawn;
            break;

        case 'P':
            currentPiece = Pieces::WhitePawn;
            break;

        case '/':
            ++y_offset;
            col = -1;
            continue;

        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
            block_offset = int(fen[i]) - int('0') - 1;
            col += block_offset;
            break;

        default:
            currentPiece = Pieces::Empty;
            break;
        };

        if (currentPiece != Pieces::Empty)
        {
            m_board[col][y_offset]->setPiece(currentPiece);
            const std::string &textureRef = m_piece_map.at(currentPiece);
            prepareTexture(renderer, textureRef, (col * BLOCK_SIZE) + BOARD_OFFSET_X, (y_offset * BLOCK_SIZE) + BOARD_OFFSET_Y);
        }
    }
}

vector<vector<int>> Board::calculatePawn(SDL_Renderer &renderer, int x, int y)
{
    vector<vector<int>> t;
    if (m_currentSelected->getPiece() == Pieces::WhitePawn)
    {
        // white
        if (y == 6) // white piece is on starting position
        {
            t.push_back(drawRect(&renderer, x, y - 1));
            t.push_back(drawRect(&renderer, x, y - 2));
        }
        else
        { // pawn is not in starting position
            t.push_back(drawRect(&renderer, x, y - 1));
        }
    }
    else
    {
        // black
        if (y == 1) // starting position
        {
            t.push_back(drawRect(&renderer, x, y + 1));
            t.push_back(drawRect(&renderer, x, y + 2));
        }
        else
        { // not in starting position
            drawRect(&renderer, x, y + 1);
        }
    }
    return t;
}

vector<int> Board::drawRect(SDL_Renderer *rend, int x, int y)
{
    vector<int> retVal;
    if (x < 0 || y > 7 || y < 0 || x > 7)
    {
        retVal.push_back(-1);
        return retVal;
    }
    else
    {
        retVal.push_back(x);
        retVal.push_back(y);
        SDL_RenderDrawRect(rend, &m_board[x][y]->returnTile());
    }
    return retVal;
}

void printVec(const vector<vector<int>> &vec)
{
    for (auto &i : vec)
    {
        for (auto &j : i)
        {
            if (j == -1)
                break;
            cout << j << ", ";
        }
        cout << endl;
    }
}

vector<vector<int>> Board::calculateBishop(SDL_Renderer &renderer, int x, int y)
{
    vector<vector<int>> retVal;
    for (int i = x + 1, j = y + 1; i < 8, j < 8; ++i, ++j)
    {
        retVal.push_back(drawRect(&renderer, i, j));
    }
    for (int i = x - 1, j = y - 1; i > -1, j > -1; --i, --j)
    {
        retVal.push_back(drawRect(&renderer, i, j));
    }
    for (int i = x + 1, j = y - 1; i<8, j> - 1; ++i, --j)
    {
        retVal.push_back(drawRect(&renderer, i, j));
    }
    for (int i = x - 1, j = y + 1; i > -1, j < 8; --i, ++j)
    {
        retVal.push_back(drawRect(&renderer, i, j));
    }
    return retVal;
}

vector<vector<int>> Board::calculateRook(SDL_Renderer &renderer, int x, int y)
{
    vector<vector<int>> retVal;
    for (int i = 0; i < x; ++i)
    {
        retVal.push_back(drawRect(&renderer, i, y));
    }
    for (int i = x + 1; i < 8; ++i)
    {
        retVal.push_back(drawRect(&renderer, i, y));
    }
    for (int i = 0; i < y - 1; ++i)
    {
        retVal.push_back(drawRect(&renderer, x, i));
    }
    for (int i = y + 1; i < 8; ++i)
    {
        retVal.push_back(drawRect(&renderer, x, i));
    }
    return retVal;
}

vector<vector<int>> Board::calculateQueen(SDL_Renderer &renderer, int x, int y)
{
    vector<vector<vector<int>>> tmp;
    vector<vector<int>> output;
    tmp.push_back(calculateBishop(renderer, x, y));
    tmp.push_back(calculateRook(renderer, x, y));
    for (auto &i : tmp)
    {
        for (auto &j : i)
        {
            output.push_back(j);
        }
    }
    return output;
}

vector<vector<int>> Board::calculateKnight(SDL_Renderer &renderer, int x, int y)
{
    vector<vector<int>> t;
    t.push_back(drawRect(&renderer, x + 2, y + 1));
    t.push_back(drawRect(&renderer, x + 2, y - 1));

    t.push_back(drawRect(&renderer, x + 1, y + 2));
    t.push_back(drawRect(&renderer, x + 1, y - 2));

    t.push_back(drawRect(&renderer, x - 2, y + 1));
    t.push_back(drawRect(&renderer, x - 2, y - 1));

    t.push_back(drawRect(&renderer, x - 1, y + 2));
    t.push_back(drawRect(&renderer, x - 1, y - 2));
    return t;
}

vector<vector<int>> Board::calculateKing(SDL_Renderer &renderer, int tilex, int tiley)
{
    vector<vector<int>> t;
    if (m_currentSelected->getPiece() == WhiteKing || m_currentSelected->getPiece() == BlackKing)
    {

        t.push_back(drawRect(&renderer, tilex + 1, tiley));
        t.push_back(drawRect(&renderer, tilex, tiley + 1));
        t.push_back(drawRect(&renderer, tilex - 1, tiley));
        t.push_back(drawRect(&renderer, tilex - 1, tiley - 1));
        t.push_back(drawRect(&renderer, tilex - 1, tiley + 1));
        t.push_back(drawRect(&renderer, tilex + 1, tiley + 1));
        t.push_back(drawRect(&renderer, tilex + 1, tiley - 1));
        t.push_back(drawRect(&renderer, tilex, tiley - 1));
    }
    return t;
}

void Board::draw(SDL_Renderer &renderer)
{
    for (int x = 0; x < 8; ++x)
    {
        for (int y = 0; y < 8; ++y)
        {
            SDL_Rect squareRect = {x * 75, y * 75, 75, 75};
            if ((x + y) % 2 == 0)
            {
                SDL_SetRenderDrawColor(&renderer, 255, 255, 255, 255);
            }
            else
            {
                SDL_SetRenderDrawColor(&renderer, 0, 0, 0, 255);
            }
            SDL_RenderFillRect(&renderer, &squareRect);
        }
    }
    std::string fen = "rnbqkbnr/pppppppp/4N/8/8/8/PPPPPPPP/RNBQKBNR";
    drawBoardPieces(fen, renderer);
}

void Board::renderTile(SDL_Renderer &renderer, int x, int y)
{
    int posX = (x * BLOCK_SIZE) + BOARD_OFFSET_X;
    int posY = (y * BLOCK_SIZE) + BOARD_OFFSET_Y;

    // Set the color for the tile based on its position (checkerboard pattern)
    if ((x + y) % 2 == 0)
    {
        SDL_SetRenderDrawColor(&renderer, 255, 255, 255, 255); // White
    }
    else
    {
        SDL_SetRenderDrawColor(&renderer, 122, 122, 122, 255); // Black
    }

    // Draw the tile
    SDL_Rect tileRect = {posX, posY, BLOCK_SIZE, BLOCK_SIZE};
    SDL_RenderFillRect(&renderer, &tileRect);

    // Check if there's a piece on this tile and render it
    if (m_board[x][y]->getPiece() != Pieces::Empty) // Assuming you have a method to get the piece
    {
        const std::string &textureRef = m_piece_map.at(m_board[x][y]->getPiece());
        prepareTexture(renderer, textureRef, posX, posY);
    }
}

void Board::movePiece(SDL_Renderer &renderer, int fromx, int fromy, int tox, int toy)
{
    if (isValidMove(fromx, fromy, tox, toy))
    {
        BoardSquare *source = m_board[fromx][fromy].get();
        BoardSquare *dest = m_board[tox][toy].get();

        if (source && dest)
        {
            dest->setPiece(source->getPiece());
            source->setPiece(Pieces::Empty);
            renderTile(renderer, fromx, fromy);
            renderTile(renderer, tox, tox);

            SDL_RenderPresent(&renderer);
        }
    }
}

bool Board::isValidMove(int fromx, int fromy, int tox, int toy)
{
    return true;
}