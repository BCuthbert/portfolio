#include <SDL2/SDL.h>
#include <vector>
#include <algorithm>
#include "board.hpp"

using std::vector;

#ifndef APPLICATION_HPP
#define APPLICATION_HPP

enum Pieces;
class BoardSquare;

class Application
{

public:
    Application() : m_board(nullptr) {}
    void draw();
    int init();
    void prepareTexture(std::string &, int, int);
    void drawBoardPieces();
    void highlightSelected();
    void clearRenderer();
    void updateRenderer();
    ~Application();
    vector<vector<int>> highlightPossibleMovesFromPosition();
    void movePiece(int, int, int, int);

private:
    SDL_Window *m_window;
    SDL_Renderer *m_renderer;
    std::unique_ptr<Board> m_board;
};

#endif
