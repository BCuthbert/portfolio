#include <SDL2/SDL.h>
#include <iostream>
// #include <stdlib.h>
#include <string>
#include <SDL2/SDL_image.h>
#include <map>
#include <memory>
#include <vector>

#include "boardsquare.hpp"

class BoardSquare;

using std::cout, std::endl;
using std::vector;

using std::pair, std::make_pair;

#ifndef BOARD_HPP
#define BOARD_HPP

const int TILE_X = 8;
const int TILE_Y = 8;
const int BOARD_SIZE = 600;

class Board
{
public:
    Board(SDL_Renderer &);
    ~Board();
    void updatePosition(SDL_Renderer &);
    void draw(SDL_Renderer &);

    void resetColors();
    void drawBoardPieces(std::string &, SDL_Renderer &);
    void setSelected(std::unique_ptr<BoardSquare>);
    void setPiece(int, int, Pieces);                // set a square to a certain piece at (x, y)
    vector<int> drawRect(SDL_Renderer *, int, int); // draws a certain rectangle at x, y (safely)

    void prepareTexture(SDL_Renderer &, const std::string &, int, int);

    vector<vector<int>> calculatePawn(SDL_Renderer &, int, int);             // calculates pawn moves
    vector<vector<int>> calculateKing(SDL_Renderer &, int, int);             // calculates king moves
    vector<vector<int>> calculateRook(SDL_Renderer &, int, int);             // calculates rook moves
    vector<vector<int>> calculateKnight(SDL_Renderer &, int, int);           // calculates knight moves
    vector<vector<int>> calculateQueen(SDL_Renderer &, int, int);            // calculates queen moves
    vector<vector<int>> calculateBishop(SDL_Renderer &m_renderer, int, int); // calculates bishop moves

    void movePiece(SDL_Renderer &, int, int, int, int);
    bool isValidMove(int, int, int, int);
    BoardSquare *returnSquare(int, int) const;
    BoardSquare *getSelected();

    std::map<Pieces, std::string> m_piece_map; // holds all pieces with their texture reference

private:
    int m_tile_x = TILE_X;
    int m_tile_y = TILE_Y;
    std::vector<std::vector<std::unique_ptr<BoardSquare>>> m_board;
    void renderTile(SDL_Renderer &renderer, int i, int j);
    std::unique_ptr<BoardSquare> m_currentSelected;
};

#endif